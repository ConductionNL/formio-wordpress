# formio-wordpress
Form.io functionality for Gravity Forms meant for Wordpress installations.

Only works if Gravity Forms is installed.

Wordpress PermaLinks setting should be set to "Post name" or other than "Plain".

If you want to retrieve a Gravity Form in form.io configuration you can send a GET request to:  
/wp-json/owc/gf-fomrio/{id}  
where id is the id of a Gravity Forms form.
