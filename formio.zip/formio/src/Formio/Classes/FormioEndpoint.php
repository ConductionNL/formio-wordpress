<?php

namespace OWC\Formio\Classes;

use OWC\Formio\Foundation\Plugin;

class FormioEndpoint
{
    /** @var Plugin */
    protected $plugin;

    public function __construct(Plugin $plugin)
    {
        $this->plugin = $plugin;
        $this->load_hooks();
        // $this->GFAPI = new WPS_Extend_Plugin('gravityforms/gravityforms.php', __FILE__, '*', 'my-plugin-text-domain');
    }

    private function load_hooks(): void
    {
        add_action('rest_api_init', function () {
            register_rest_route('conduction/v1', '/form/(?P<id>\d+)', array(
                'methods' => 'GET',
                'callback' => [$this, 'gravityFormToFormIO'],
            ));
        });
    }

    /**
     * Grab latest post title by an author!
     *
     * @param array $data Options for the function.
     * @return string|null Post title for the latest, * or null if none.
     */
    public function gravityFormToFormIO($data)
    {
        if (class_exists('GFAPI')) {
            return \GFAPI::get_forms();
        } else {
            return ['message' => 'Gravity Forms is not installed'];
        }

        return ['components' => ['id' => $data['id']]];
    }
}
